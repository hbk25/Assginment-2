# Quiz-App-
My first android app build with kotlin. It's a quiz app with decent UI and intents.
# Screenshots


## Opening UI
<img src="1.jpeg"/>


## Question page UI
<img src="2.jpeg"/>


## Ending Activity UI
<img src="3.jpeg"/>
